package ingest

import (
	"errors"
	"fmt"
	"go.mongodb.org/mongo-driver/mongo"
	"testing"
)

func TestImageSetupIndexBuildIsRetryable(t *testing.T) {
	busy := mongo.CommandError{Name: "BackgroundOperationInProgressForNamespace", Code: 12587, Message: "index build running"}
	err := imageSetupError(fmt.Errorf("enable exact images: %w", busy))
	var gap *CaptureError
	if errors.As(err, &gap) {
		t.Fatal("temporary index build incorrectly marks permanent capture gap")
	}
	var command mongo.CommandError
	if !errors.As(err, &command) {
		t.Fatal("retry lost original MongoDB error")
	}
	denied := imageSetupError(mongo.CommandError{Name: "Unauthorized", Code: 13})
	if !errors.As(denied, &gap) {
		t.Fatal("permission failure must be visible as degraded capture")
	}
}
