package wal_test

import (
	"context"
	"testing"
	"time"

	"github.com/argon-lab/argon/internal/ingest"
	"github.com/argon-lab/argon/internal/snapshot"
	"github.com/stretchr/testify/require"
	"go.mongodb.org/mongo-driver/bson"
)

func captureContext(t *testing.T) context.Context {
	t.Helper()
	ctx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	t.Cleanup(cancel)
	return ctx
}

func TestCapture_CompetingWatchersDoNotDuplicateHistory(t *testing.T) {
	f := newIngestFixture(t, "capture-competing")
	ctx := captureContext(t)
	other := ingest.NewService(f.client, f.metaDB, f.wal, f.branches)
	require.NoError(t, f.ingest.Start(ctx, f.branchID))
	require.NoError(t, other.Start(ctx, f.branchID))
	for batch := 0; batch < 6; batch++ {
		for i := 0; i < 5; i++ {
			_, err := f.physical.Collection("users").UpdateOne(ctx, bson.M{"_id": "seed"}, bson.M{"$inc": bson.M{"n": 1}})
			require.NoError(t, err)
		}
		// Either watcher can win the checkpoint transaction; both callers
		// must observe completion without waiting for a skipped local event.
		drained := make(chan error, 2)
		go func() { drained <- f.ingest.Drain(ctx, f.branchID) }()
		go func() { drained <- other.Drain(ctx, f.branchID) }()
		require.NoError(t, <-drained)
		require.NoError(t, <-drained)
	}
	require.NoError(t, f.ingest.Stop(ctx, f.branchID))
	require.NoError(t, other.Stop(ctx, f.branchID))
	branch, err := f.branches.GetBranchByID(f.branchID)
	require.NoError(t, err)
	entries, err := f.wal.GetBranchEntries(f.branchID, "users", 0, branch.HeadLSN)
	require.NoError(t, err)
	require.Len(t, entries, 31, "each native event must be logged only once across competing checkpoints")
	state, err := f.matFull.MaterializeCollection(branch, "users")
	require.NoError(t, err)
	require.EqualValues(t, 30, state["seed"]["n"])
}

func TestCapture_PreImagesAreEnabledIndependentlyPerPhysicalDatabase(t *testing.T) {
	f := newIngestFixture(t, "capture-collections")
	ctx := captureContext(t)
	child, err := f.branches.CreateBranch("capture-collections", "second", f.branchID)
	require.NoError(t, err)
	info, err := f.checkout.Checkout(ctx, child.ID)
	require.NoError(t, err)
	second := f.client.Database(info.PhysicalDB)
	t.Cleanup(func() { _ = second.Drop(context.Background()) })
	for _, id := range []string{f.branchID, child.ID} {
		branch, err := f.branches.GetBranchByID(id)
		require.NoError(t, err)
		coll := f.client.Database(branch.PhysicalDB).Collection("new_collection")
		_, err = coll.InsertOne(ctx, bson.M{"_id": "a", "n": 1})
		require.NoError(t, err)
		require.NoError(t, f.ingest.Start(ctx, id))
		_, err = coll.UpdateOne(ctx, bson.M{"_id": "a"}, bson.M{"$set": bson.M{"n": 2}})
		require.NoError(t, err)
		require.NoError(t, f.ingest.Drain(ctx, id))
		branch, err = f.branches.GetBranchByID(id)
		require.NoError(t, err)
		entries, err := f.wal.GetBranchEntries(id, "new_collection", 0, branch.HeadLSN)
		require.NoError(t, err)
		require.Len(t, entries, 2)
		require.NotEmpty(t, entries[1].PreImage, "same collection name in another physical database must also enable images")
	}
	require.NoError(t, f.ingest.Shutdown(ctx))
}

func TestCapture_CheckoutPreservesUncapturedWritesAndFirstWatchRecovers(t *testing.T) {
	f := newIngestFixture(t, "capture-first")
	ctx := captureContext(t)
	_, err := f.physical.Collection("users").UpdateOne(ctx, bson.M{"_id": "seed"}, bson.M{"$set": bson.M{"n": int32(42)}})
	require.NoError(t, err)
	// A repeated connection request must not drop this un-ingested write.
	_, err = f.checkout.Checkout(ctx, f.branchID)
	require.NoError(t, err)
	var physical bson.M
	require.NoError(t, f.physical.Collection("users").FindOne(ctx, bson.M{"_id": "seed"}).Decode(&physical))
	require.EqualValues(t, 42, physical["n"])
	require.NoError(t, f.ingest.Start(ctx, f.branchID, ingest.WithActor("agent:run-42")))
	t.Cleanup(func() { require.NoError(t, f.ingest.Shutdown(context.Background())) })
	require.NoError(t, f.ingest.Drain(ctx, f.branchID))
	branch, err := f.branches.GetBranchByID(f.branchID)
	require.NoError(t, err)
	state, err := f.matFull.MaterializeCollection(branch, "users")
	require.NoError(t, err)
	require.EqualValues(t, 42, state["seed"]["n"])
	entries, err := f.wal.GetBranchEntries(f.branchID, "users", 0, branch.HeadLSN)
	require.NoError(t, err)
	require.Len(t, entries, 2, "checkout seed must not be ingested a second time")
	require.Equal(t, "agent:run-42", entries[1].Actor)
	require.Equal(t, "update", entries[1].Metadata["capture_operation"])
}

func TestCapture_ExactIntermediateImagesDrainAndAutoSnapshots(t *testing.T) {
	f := newIngestFixture(t, "capture-images")
	ctx := captureContext(t)
	f.snapshots.EnableAuto(snapshot.AutoConfig{Threshold: 5, CheckEvery: 1, Synchronous: true})
	f.ingest.SetAutoSnapshotter(f.snapshots)
	require.NoError(t, f.ingest.Start(ctx, f.branchID))
	for i := 1; i <= 25; i++ {
		_, err := f.physical.Collection("users").UpdateOne(ctx, bson.M{"_id": "seed"}, bson.M{"$set": bson.M{"n": int32(i)}})
		require.NoError(t, err)
	}
	_, err := f.physical.Collection("users").DeleteOne(ctx, bson.M{"_id": "seed"})
	require.NoError(t, err)
	// Stop must include the final acknowledged delete, even without polling.
	require.NoError(t, f.ingest.Stop(ctx, f.branchID))
	branch, err := f.branches.GetBranchByID(f.branchID)
	require.NoError(t, err)
	entries, err := f.wal.GetBranchEntries(f.branchID, "users", 0, branch.HeadLSN)
	require.NoError(t, err)
	require.Len(t, entries, 27)
	for i := 1; i <= 25; i++ {
		var post, pre bson.M
		require.NoError(t, bson.Unmarshal(entries[i].PostImage, &post))
		require.NoError(t, bson.Unmarshal(entries[i].PreImage, &pre))
		require.EqualValues(t, i, post["n"], "event post-image must be exact, not a later updateLookup")
		require.EqualValues(t, i-1, pre["n"])
	}
	count, err := f.metaDB.Collection("wal_snapshots").CountDocuments(ctx, bson.M{"branch_id": f.branchID})
	require.NoError(t, err)
	require.Positive(t, count, "native writes must trigger automatic snapshots")
}

func TestCapture_DDLMarksPersistedDegradedHealth(t *testing.T) {
	f := newIngestFixture(t, "capture-ddl")
	ctx := captureContext(t)
	require.NoError(t, f.ingest.Start(ctx, f.branchID))
	require.NoError(t, f.physical.Collection("users").Drop(ctx))
	require.Eventually(t, func() bool {
		for _, status := range f.ingest.Statuses() {
			if status.BranchID == f.branchID && status.State == "degraded" {
				return true
			}
		}
		return false
	}, 10*time.Second, 20*time.Millisecond)
	var stored struct {
		Capture ingest.Status `bson:"capture_status"`
	}
	require.NoError(t, f.metaDB.Collection("wal_ingest_state").FindOne(ctx, bson.M{"_id": f.branchID}).Decode(&stored))
	require.Equal(t, "degraded", stored.Capture.State)
	require.Contains(t, stored.Capture.Error, "drop")
	// Neither drain nor release may pretend the missing DDL is durable.
	require.Error(t, f.ingest.Drain(ctx, f.branchID))
}
